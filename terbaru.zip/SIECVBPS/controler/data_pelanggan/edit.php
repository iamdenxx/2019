<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$pelanggan=$_POST['pelanggan'];
	$alamat=$_POST['alamat'];
	$status=$_POST['status'];


	mysqli_query($konek,"update tb_pelanggan set pelanggan='$pelanggan',alamat='$alamat',status='$status' where id_pelanggan='$id'");
	header('location:../../data_pelanggan.php');
    
?>