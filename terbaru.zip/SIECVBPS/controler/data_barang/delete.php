<?php
	include('../../includes/koneksi.php');
	$id=$_GET['id'];
	mysqli_query($konek,"delete from tb_barang where id_barang='$id'");
	header('location:../../data_barang.php');

?>