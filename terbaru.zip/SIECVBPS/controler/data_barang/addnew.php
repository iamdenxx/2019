<?php
	include('../../includes/koneksi.php');
	
	$type_barang=$_POST['type_barang'];
	$merk=$_POST['merk'];
	$kategori=$_POST['kategori'];
	$rp=$_POST['harga'];
	$harga=str_replace(".", "", $rp);


	mysqli_query($konek,"insert into tb_barang (type_barang, merk, kategori, harga) values ('$type_barang', '$merk', '$kategori','$harga')");
	header('location:../../data_barang.php');
?>