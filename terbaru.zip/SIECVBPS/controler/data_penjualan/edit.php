<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$tgl=$_POST['tgl_transaksi'];
	$pelanggan=$_POST['pelanggan'];
	$type=$_POST['type_barang'];
	$satuan=$_POST['satuan'];
	$merk=$_POST['merk_barang'];
	$kategori=$_POST['kategori'];
	$qty=$_POST['qty'];
	$j_pelanggan=$_POST['jenis_pelanggan'];
	$j_pembayaran=$_POST['jenis_pembayaran'];
	$s_pembayaran=$_POST['status'];

	$rp=$_POST['harga'];
	$harga=str_replace(".", "", $rp);

    $tot=$_POST['total'];
	$total=str_replace(".", "", $tot);
    $tf=$_POST['transfer'];
	$tft=str_replace(".", "", $tf);

	$ca=$_POST['cash'];
	$cash=str_replace(".", "", $ca);

	$sis=$_POST['sisa'];
	$sisa=str_replace(".", "", $sis);
	

	mysqli_query($konek,"update tb_penjualan set tgl_transaksi='$tgl',nama_pelanggan='$pelanggan', type_barang='$type', merk_barang='$merk', kategori_barang='$kategori', harga='$harga', qty='$qty',satuan='$satuan',total='$total',jenis_pelanggan='$j_pelanggan',jenis_pembayaran='$j_pembayaran',transfer='$transfer',cash='$cash',status_pembayaran='$s_pembayaran',sisa='$sisa' where id_transaksi='$id'");

	header('location:../../data_penjualan.php');
    
?>