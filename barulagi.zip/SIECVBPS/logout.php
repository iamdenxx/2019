<?php
session_start();
session_destroy();

	echo '<script language="javascript">alert("Logout Success !"); document.location="login.php";</script>';

?>