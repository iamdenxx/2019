<?php
	include('../../includes/koneksi.php');
	


	$tgl=$_POST['tgl_transaksi'];
	$pelanggan=$_POST['pelanggan'];
	$type=$_POST['type_barang'];
	$merk=$_POST['merk_barang'];
	$kategori=$_POST['kategori_barang'];
	$harga=$_POST['harga'];
	$qty=$_POST['qty'];
	$satuan=$_POST['satuan'];
	$total=$_POST['total'];
	$tft=$_POST['transfer'];
	$cash=$_POST['cash'];
	$sisa=$_POST['sisa'];
	$j_pelanggan=$_POST['jenis_pelanggan'];
	$j_pembayaran=$_POST['jenis_pembayaran'];
	$s_pembayaran=$_POST['status'];
	

	mysqli_query($konek,"insert into tb_penjualan (tgl_transaksi, nama_pelanggan, type_barang,merk_barang,kategori_barang,harga,qty,satuan,total,jenis_pelanggan,jenis_pembayaran,transfer,cash,status_pembayaran,sisa) values ('$tgl', '$pelanggan', '$type','$merk','$kategori','$harga','$qty','$satuan','$total','$j_pelanggan','$j_pembayaran','$tft','$cash','$s_pembayaran','$sisa')");
	header('location:../../data_penjualan.php');
?>
	
