<?php
	include('../../includes/koneksi.php');
	$id=$_GET['id'];
	mysqli_query($konek,"delete from tb_penjualan where id_transaksi='$id'");
	header('location:../../data_penjualan.php');

?>