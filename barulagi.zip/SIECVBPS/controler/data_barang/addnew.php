<?php
	include('../../includes/koneksi.php');
	
	$type_barang=$_POST['type_barang'];
	$merk=$_POST['merk'];
	$kategori=$_POST['kategori'];
	$harga=$_POST['harga'];

	mysqli_query($konek,"insert into tb_barang (type_barang, merk, kategori, harga) values ('$type_barang', '$merk', '$kategori','$harga')");
	header('location:../../data_barang.php');
?>