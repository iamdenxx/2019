<!-- Delete -->
    <div class="modal fade" id="del<?php echo $data['id_merk']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Apakah Anda Akan Menghapus Data Berikut ?</h4></center>
                </div>
                <div class="modal-body">
				<?php
                include_once 'includes/koneksi.php';
					$del=mysqli_query($konek,"select * from tb_merk where id_merk='".$data['id_merk']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">

					<h5><center>Jenis Barang</center>
						<strong><center><?php echo $drow['merk']; ?></strong></center>
					</h5> 
					

                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_jenis/delete.php?id=<?php echo $data['id_merk']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $data['id_merk']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel"><b>EDIT DATA JENIS</b></h4></center>
                </div>
                <div class="modal-body">
				<?php
                include_once '../../includes/koneksi.php';
					$edit=mysqli_query($konek,"select * from tb_merk where id_merk='".$data['id_merk']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="controler/data_merk/edit.php?id=<?php echo $erow['id_merk']; ?>">
					
					<div class="row">
						<div class="col-lg-4">
							<label style="position:relative; top:7px;">Nama merk:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" name="merk" class="form-control" value="<?php echo $erow['merk']; ?>">
						</div>
					</div>
				
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->