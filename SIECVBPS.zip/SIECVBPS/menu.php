<!-- SIDE MENU -->
		<ul class="nav menu">
			<li><a href="index.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<!-- Menu -->
			<li><a href="data_penjualan.php"><em class="fa fa-bar-chart">&nbsp;</em>Data Penjualan</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> Data System <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li><a class="" href="data_barang.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Data Barang
					</a></li>
					<li><a class="" href="data_merk.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Merk Barang
					</a></li>
					<li><a class="" href="data_kategori.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Kategori Barang
					</a></li>
					<li><a class="" href="data_pelanggan.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Data Pelanggan
					</a></li>
					<li><a class="" href="data_user.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Data User
					</a></li>
					
				</ul>
			</li>
			<li><a href="data_laporan.php"><em class="fa fa-clone">&nbsp;</em>Laporan</a></li>
			<!--<li><a href="elements.html"><em class="fa fa-toggle-off">&nbsp;</em> UI Elements</a></li>
			-->
			<li><a href="logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->