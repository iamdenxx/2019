<!-- Delete -->
    <div class="modal fade" id="del<?php echo $data['id_transaksi']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Apakah Anda Akan Menghapus Data Berikut ?</h4></center>
                </div>
                <div class="modal-body">
				<?php
				include_once '../../includes/koneksi.php';
					$del=mysqli_query($konek,"select * from tb_penjualan where id_transaksi='".$data['id_transaksi']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center>TGL Transaksi</center>
					<strong><center><?php echo $drow['tgl_transaksi']; ?></strong></center>
				    </h5> 
				    <h5><center>Nama Pelanggan</center>
						<strong><center><?php echo $drow['nama_pelanggan']; ?></strong></center>
					</h5> 
					<h5><center>Type Barang</center>
						<strong><center><?php echo $drow['type_barang']; ?></strong></center>
					</h5> 
					

                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_penjualan/delete.php?id=<?php echo $data['id_transaksi']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $data['id_transaksi']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel"><b>EDIT DATA PENJUALAN</b></h4></center>
                    
                </div>
                <div class="modal-body">
				<?php
				include_once '../../includes/koneksi.php';
					$edit=mysqli_query($konek,"select * from tb_penjualan where id_transaksi='".$data['id_transaksi']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="controler/data_penjualan/edit.php?id=<?php echo $erow['id_transaksi']; ?>">
					<div class="row">
						<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">TGL Transaksi:</label>
						</div>
						<div class="col-lg-3">
							<input type="date" class="form-control" name="tgl_transaksi" value="<?php echo $erow['tgl_transaksi']; ?>">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Nama Pelanggan:</label>
						</div>
						<div class="col-lg-2">
							<select required class="form-control" id="pelanggan" name="pelanggan" value="">
									<option><?php echo $erow['nama_pelanggan']; ?></option>
									<?php 
									include_once '../../includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_pelanggan");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['pelanggan']."'>".$data['pelanggan']."</option>";
									}
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Type Barang:</label>
						</div>
						<div class="col-lg-2">
							<select  value="" required class="form-control" id="type_barang" name="type_barang">
									
									<option><?php echo $erow['type_barang']; ?></option>
									<?php 
									include_once '../../includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_barang");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['type_barang']."'>".$data['type_barang']."</option>";
									}
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Merk:</label>
						</div>
						<div class="col-lg-2">
							<select  value="" required class="form-control" id="merk_barang" name="merk_barang">
									
									<option><?php echo $erow['merk_barang']; ?></option>
									<?php 
									include_once '../../includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_merk");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['merk']."'>".$data['merk']."</option>";
									}
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Kategori:</label>
						</div>
						<div class="col-lg-3">
							<select  value="" required class="form-control" id="kategori" name="kategori">
									
									<option><?php echo $erow['kategori_barang']; ?></option>
									<?php
									include_once '../../includes/koneksi.php'; 
					                 $query=mysqli_query($konek,"select * from tb_kategori");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['kategori']."'>".$data['kategori']."</option>";
									}
									?>
								</select>
						</div>
					</div>
			           
			        <div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Harga:</label>
						</div>
						<div class="col-lg-3">
							<input type="text" class="form-control" id="harga"name="harga" value="<?php echo $erow['harga']; ?>">
						</div>
					</div>

  					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">QTY:</label>
						</div>
						<div class="col-lg-3">
							<input type="text" class="form-control" id="qty" name="qty" value="<?php echo $erow['qty']; ?>">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Total:</label>
						</div>
						<div class="col-lg-3">
							<input type="text" class="form-control" id="total" name="total" value="<?php echo $erow['total']; ?>">
						</div>
					</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Jenis Pelanggan:</label>
						</div>
						<div class="col-lg-5">
								<input type="radio" name="jenis_pelanggan" value="Online" <?php echo($erow['jenis_pelanggan']=='Online')? "checked":"";?>/> Online
								<input type="radio" name="jenis_pelanggan" value="Direct" <?php echo($erow['jenis_pelanggan']=='Direct')? "checked":"";?>/> Direct
							</div>
						</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Jenis Pembayaran:</label>
						</div>
						<div class="col-lg-5">

								<input type="radio" name="jenis_pembayaran" value="Transfer" <?php echo($erow['jenis_pembayaran']=='Transfer')? "checked":"";?>/> Transfer
								<input type="radio" name="jenis_pembayaran" value="Cash" <?php echo($erow['jenis_pembayaran']=='Cash')? "checked":"";?>/> Cash
							</div>
						</div>

					<div style="height:15px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Status Pembayaran:</label>
						</div>
						<div class="col-lg-5">
								<input type="radio" name="status_pembayaran" value="Lunas" <?php echo($erow['status_pembayaran']=='Lunas')? "checked":"";?>/> Lunas
								<input type="radio" name="status_pembayaran" value="Kredit" <?php echo($erow['status_pembayaran']=='Kredit')? "checked":"";?>/> Kredit
							</div>
						</div>
                </div> 
				</div>
			</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->