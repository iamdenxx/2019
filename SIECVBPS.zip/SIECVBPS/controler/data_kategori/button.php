<!-- Delete -->
    <div class="modal fade" id="del<?php echo $data['id_kategori']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Apakah Anda Akan Menghapus Data Berikut ?</h4></center>
                </div>
                <div class="modal-body">
				<?php
                include_once '../../includes/koneksi.php';
					$del=mysqli_query($konek,"select * from tb_kategori where id_kategori='".$data['id_kategori']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">

					<h5><center>Kategori</center>
						<strong><center><?php echo $drow['kategori']; ?></strong></center>
					</h5> 
				

                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_kategori/delete.php?id=<?php echo $data['id_kategori']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $data['id_kategori']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel"><b>EDIT DATA KATEGORI</b></h4></center>
                </div>
                <div class="modal-body">
				<?php
                include_once '../../includes/koneksi.php';
					$edit=mysqli_query($konek,"select * from tb_kategori where id_kategori='".$data['id_kategori']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="controler/data_kategori/edit.php?id=<?php echo $erow['id_kategori']; ?>">
					<div class="row">
						<div class="col-lg-4">
							<label style="position:relative; top:7px;">Nama Kategori:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" name="kategori" class="form-control" value="<?php echo $erow['kategori']; ?>">
						</div>
					</div>
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span></span> Save</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->