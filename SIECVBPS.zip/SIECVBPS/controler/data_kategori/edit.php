<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$kategori=$_POST['kategori'];
	

	mysqli_query($konek,"update tb_kategori set kategori='$kategori' where id_kategori='$id'");

	header('location:../../data_kategori.php');

?>