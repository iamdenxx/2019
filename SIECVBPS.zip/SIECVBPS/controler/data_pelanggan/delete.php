<?php
	include('../../includes/koneksi.php');
	$id=$_GET['id'];
	mysqli_query($konek,"delete from tb_pelanggan where id_pelanggan='$id'");
	header('location:../../data_pelanggan.php');

?>