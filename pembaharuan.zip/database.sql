/*
SQLyog Ultimate - MySQL GUI v8.21 
MySQL - 5.5.5-10.1.33-MariaDB : Database - db_siexp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_siexp` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `db_siexp`;

/*Table structure for table `tb_barang` */

DROP TABLE IF EXISTS `tb_barang`;

CREATE TABLE `tb_barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `type_barang` varchar(50) NOT NULL,
  `merk` char(50) NOT NULL,
  `kategori` char(50) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY (`id_barang`),
  UNIQUE KEY `id` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `tb_barang` */

insert  into `tb_barang`(`id_barang`,`type_barang`,`merk`,`kategori`,`harga`) values (1,'BRG001','Kaca','Perabotan',70),(2,'BRG002','Lampu Merah','Perabotan',50),(3,'BRG003','Lampu Merah','Perabotan',10),(4,'BRG004','Lampu Merah','Perabotan',8),(5,'BRG005','Lampu Merah','Perabotan',9999),(18,'XP7000','Yamaha','Amplifier',8500000),(19,'MG10XU','Yamaha','Mixer',2900000),(20,'360PIIG','BOSE','Speaker Pasif',8000000);

/*Table structure for table `tb_kategori` */

DROP TABLE IF EXISTS `tb_kategori`;

CREATE TABLE `tb_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` char(50) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `tb_kategori` */

insert  into `tb_kategori`(`id_kategori`,`kategori`) values (1,'Perabotan'),(2,'Amplifier'),(3,'Mixer'),(4,'Speaker Pasif');

/*Table structure for table `tb_merk` */

DROP TABLE IF EXISTS `tb_merk`;

CREATE TABLE `tb_merk` (
  `id_merk` int(11) NOT NULL AUTO_INCREMENT,
  `merk` char(50) NOT NULL,
  PRIMARY KEY (`id_merk`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `tb_merk` */

insert  into `tb_merk`(`id_merk`,`merk`) values (1,'Lampu Merah'),(2,'Kaca'),(3,'Yamaha'),(4,'Yamaha'),(5,'BOSE');

/*Table structure for table `tb_pelanggan` */

DROP TABLE IF EXISTS `tb_pelanggan`;

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `pelanggan` char(50) NOT NULL,
  `alamat` text NOT NULL,
  `status` char(10) NOT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `tb_pelanggan` */

insert  into `tb_pelanggan`(`id_pelanggan`,`pelanggan`,`alamat`,`status`) values (1,'CV Test','',''),(2,'CV Test 2','',''),(3,'Villa Cecile','-','-'),(4,'Villa Cecile','-','-'),(5,'Villa Cecile','-','-');

/*Table structure for table `tb_penjualan` */

DROP TABLE IF EXISTS `tb_penjualan`;

CREATE TABLE `tb_penjualan` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_transaksi` date NOT NULL,
  `nama_pelanggan` char(50) NOT NULL,
  `type_barang` varchar(150) NOT NULL,
  `merk_barang` char(50) NOT NULL,
  `kategori_barang` char(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `satuan` char(10) NOT NULL,
  `total` int(11) NOT NULL,
  `jenis_pelanggan` char(50) NOT NULL,
  `jenis_pembayaran` char(50) NOT NULL,
  `transfer` int(11) NOT NULL,
  `cash` int(11) NOT NULL,
  `status_pembayaran` char(50) NOT NULL,
  `sisa` int(11) NOT NULL,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `tb_penjualan` */

insert  into `tb_penjualan`(`id_transaksi`,`tgl_transaksi`,`nama_pelanggan`,`type_barang`,`merk_barang`,`kategori_barang`,`harga`,`qty`,`satuan`,`total`,`jenis_pelanggan`,`jenis_pembayaran`,`transfer`,`cash`,`status_pembayaran`,`sisa`) values (1,'2019-01-24','CV Test 2','BRG001','Lampu Merah','Perabotan',70,1,'Pcs',70,'Online','Transfer',70,0,'Lunas',0),(3,'2019-02-22','CV Test 2','BRG002','Lampu Merah','Perabotan',50,5,'Pcs',250,'Online','Transfer & Cash',50,200,'Lunas',0),(4,'2002-10-19','Villa Cecile','XP7000','Yamaha','Amplifier',8500000,1,'Pcs',8500000,'Direct','Transfer',8500000,0,'Lunas',0),(5,'2002-07-19','Villa Cecile','MG10XU','Yamaha','Mixer',2900000,1,'Pcs',2900000,'Online','Cash',0,2000000,'Sisa',900000),(6,'2019-02-28','Villa Cecile','BRG003','Lampu Merah','Perabotan',10,7,'',70,'','Transfer',70,0,'Lunas',0),(7,'2019-02-19','Villa Cecile','BRG003','Lampu Merah','Perabotan',10,8,'',80,'','Transfer',80,0,'Lunas',0),(8,'2019-02-17','CV Test 2','BRG002','Lampu Merah','Perabotan',50,5,'',250,'','Transfer',250,0,'Lunas',0);

/*Table structure for table `tb_user` */

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` char(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `tb_user` */

insert  into `tb_user`(`id`,`nama`,`username`,`password`,`user_level`) values (1,'Admin','admin','$2y$10$lVs5NKyzfwzg4P59xyvaZe2NMYmp.XGRnxKilZdejUtSRa9QrR9py',1),(2,'Pimpinan','Bos','$2y$10$n5m0YuaH8HXq1B/AKsWIseS6NRRTZ0OylBYcmTWB1SbGMXL2ewXlG',2),(4,'bjhbjhb','gujhvjh','$2y$10$F7lY67itixsln0.RLOi5L.sqXx/XL6RfXcy/X0TgUg52x35LRvSwu',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
