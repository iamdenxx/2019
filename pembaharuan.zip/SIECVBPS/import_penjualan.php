<?php


// Load file koneksi.php
include "includes/koneksi.php";

if(isset($_POST['import'])){ // Jika user mengklik tombol Import
    $nama_file_baru = 'data.xlsx';
    
    // Load librari PHPExcel nya
    require_once 'PHPExcel/PHPExcel.php';
    
    $excelreader = new PHPExcel_Reader_Excel2007();
    $loadexcel = $excelreader->load('tmp/data_pelanggan/'.$nama_file_baru); // Load file excel yang tadi diupload ke folder tmp
    $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
    
    // Buat query Insert
    $query = "INSERT INTO db_siexp.tb_penjualan VALUES";
    
    $numrow = 1;
    foreach($sheet as $row){
        // Ambil data pada excel sesuai Kolom
        $id='';
            $tgl= $row['C'];
            $pelanggan = $row['K'];
            $type= $row['D'];
            $merk= $row['I'];
            $kategori= $row['J'];
            $harga= $row['G'];
            $qty= $row['E'];
            $satuan= $row['F'];
            $total= $row['H'];
            $jenis_pel= $row['L'];
            $jenis_pem= $row['M'];
            $transfer= $row['N'];
            $cash= $row['O'];
            $status= $row['P'];
            $sisa= $row['Q']; // Ambil data Node
      
        
        
        // Cek jika semua data tidak diisi
       if(empty($id) && empty($tgl) && empty($pelanggan) && empty($type) && empty($merk) && empty($kategori) && empty($harga) && empty($qty) && empty($satuan) && empty($total) && empty($jenis_pel) && empty($jenis_pem) && empty($transfer) && empty($cash) && empty($status) && empty($sisa))
              continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)
            
        // Cek $numrow apakah lebih dari 1
        // Artinya karena baris pertama adalah nama-nama kolom
        // Jadi dilewat saja, tidak usah diimport
        if($numrow > 1){
            // Tambahkan value yang akan di insert ke variabel $query
            $query .= "('".$id."','".$tgl."','".$pelanggan."','".$type."','".$merk."','".$kategori."','".$harga."','".$qty."','".$satuan."','".$total."','".$jenis_pel."','".$jenis_pem."','".$transfer."','".$cash."','".$status."','".$sisa."'),";
        }
        
        $numrow++; // Tambah 1 setiap kali looping
    }
    
    // Kita hilangkan tanda koma di akhir query
    // sehingga kalau di echo $query nya akan sepert ini : (contoh ada 2 data siswa)
    // INSERT INTO siswa VALUES('1011001','Rizaldi','Laki-laki','089288277372','Bandung'),('1011002','Siska','Perempuan','085266255121','Jakarta');
    $query = substr($query, 0, strlen($query) - 1).";";
    
    // Eksekusi $query
    mysqli_query($konek, $query);
    
}

header('location: data_penjualan.php'); // Redirect ke halaman awal

?>