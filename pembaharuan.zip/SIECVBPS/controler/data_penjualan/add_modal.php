<!-- Add New -->
    <div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Tambah Data Penjualan</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
				<form name='autoSumForm' method="POST" action="controler/data_penjualan/addnew.php">
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">TGL Transaksi:</label>
						</div>
						<div class="col-lg-5">
							<input type="date" class="form-control" name="tgl_transaksi">
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Nama Pelanggan:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="pelanggan" name="pelanggan">
									<option value="" disabled selected>Pilih Pelanggan</option>;
									<?php  
									include_once 'includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_pelanggan");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['pelanggan']."'>".$data['pelanggan']."</option>";
									}
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Type Barang:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="type_barang" name="type_barang" onchange="changeValue(this.value)">
									<option value="" disabled selected>Pilih Type Barang</option>;
									<?php 
									include_once 'includes/koneksi.php';
									$jsArray = "var harga = new Array();\n";
									$jsArray2 = "var merk_barang = new Array();\n"; 
									$jsArray3 = "var kategori_barang = new Array();\n";  
					                 $query=mysqli_query($konek,"select * from tb_barang");
					                  while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['type_barang']."'>".$data['type_barang']."</option>";
									 $jsArray .= "harga['" . $data['type_barang'] . "'] = {satu:'" . addslashes($data['harga']) . "'};\n";
									 $jsArray2 .= "merk_barang['" . $data['type_barang'] . "'] = {dua:'" . addslashes($data['merk']) . "'};\n";
									 $jsArray3 .= "kategori_barang['" . $data['type_barang'] . "'] = {tiga:'" . addslashes($data['kategori']) . "'};\n";
									}
									?>
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Merk:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="merk_barang" name="merk_barang">
									<option value="" disabled selected>Pilih Merk Barang</option>;
									<?php  
									include_once 'includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_merk");
					                 while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['merk']."'>".$data['merk']."</option>";
									}
									?>
								</select>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Kategori:</label>
						</div>
						<div class="col-lg-5">
							<select onchange="cek_database()" required class="form-control" id="kategori_barang" name="kategori_barang">
									<option value="" disabled selected>Pilih Kategori</option>;
									<?php  
									include_once 'includes/koneksi.php';
					                 $query=mysqli_query($konek,"select * from tb_kategori");
					                  while ($data=mysqli_fetch_array($query))
					                 {
									 echo "<option value='".$data['kategori']."'>".$data['kategori']."</option>";
									}
									?>
								</select>
						</div>
					</div>
			           
			        <div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Harga:</label>
						</div>

						<div class="col-lg-5">
							<input type="text" class="form-control" id="harga"name="harga" placeholder="harga"  onFocus="startCalc();" onBlur="stopCalc();" />
						</div>
					</div>

  					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">QTY:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="qty" name="qty" placeholder="quantity"  onFocus="startCalc();" onBlur="stopCalc();" />
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Satuan:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="satuan" name="satuan">
									<option selected disabled>Pilih Satuan</option>;
									<option value="Pcs">Pcs</option>;
									<option value="Unit">Unit</option>;
									<option value="Pair">Pair</option>;
									<option value="Roll">Roll</option>;
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Total:</label>
						</div>
						<div class="col-lg-5">
							<input readonly type="text" class="form-control" id="total" name="total" onchange='tryNumberFormat(this.form.twoBox);' onchange="changeValue(this.value)"  readonly>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Jenis Pembayaran:</label>
						</div>
						<div class="col-lg-5">
							<select required class="form-control" id="jenis_pembayaran" name="jenis_pembayaran">
									<option value="" disabled selected>Pilih Metode Bayar</option>;
									<option value="Transfer">Transfer</option>;
									<option value="Cash">Cash</option>;
									<option value="Transfer & Cash">Transfer & Cash</option>;
									
								</select>
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Transfer:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="transfer"name="transfer" placeholder="Rp."  onFocus="startCalc();" onBlur="stopCalc();" />
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Cash:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="cash"name="cash" placeholder="Rp."  onFocus="startCalc();" onBlur="stopCalc();" />
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Status Pembayaran:</label>
						</div>
						<div class="col-lg-5">
							<input type="text" class="form-control" id="status"name="status" />
						</div>
					</div>

					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-3">
							<label class="control-label" style="position:relative; top:7px;">Sisa:</label>
						</div>
						<div class="col-lg-5">
							<input readonly type="text" class="form-control" id="sisa" name="sisa" onchange='tryNumberFormat(this.form.twoBox);'  readonly>
						</div>
					</div>

				</div>
			</div>
			
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a></button>
				</form>
				<script type="text/javascript">
<?php echo $jsArray;
	  echo $jsArray2;
	  echo $jsArray3; 
?>
function changeValue(id){
document.getElementById('harga').value = harga[id].satu;
document.getElementById('merk_barang').value = merk_barang[id].dua;
document.getElementById('kategori_barang').value = kategori_barang[id].tiga;
};
</script>

<script><!-- 

function startCalc(){
interval = setInterval("calc()",1);}
function calc(){
one = document.autoSumForm.harga.value;
two = document.autoSumForm.qty.value; 
three = document.autoSumForm.transfer.value;
four = document.autoSumForm.cash.value;
//three = document.autoSumForm.diskon.value; 
document.autoSumForm.total.value = (one * 1) * (two * 1);
document.autoSumForm.sisa.value = ((one*1)*(two*1))-(three*1+four*1);
if (document.autoSumForm.sisa.value==0) {
	document.autoSumForm.status.value="Lunas"
} else {
	document.autoSumForm.status.value="Sisa"
}
}
function stopCalc(){
clearInterval(interval);}

</script>
<script type="text/javascript" src="asset/js/rp.js"></script>

          </div>	
         </div>
        </div>
       </div>
       
    