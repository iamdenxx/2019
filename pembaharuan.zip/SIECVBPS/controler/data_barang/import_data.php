 <div class="modal fade" id="import" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Import Data</h4></center>
                </div>
                <div class="modal-body">
          <div class="container-fluid">

      <!-- Buat sebuah tag form dan arahkan action nya ke file ini lagi -->
      <form method="post" action="controler/data_barang/import.php" enctype="multipart/form-data"> 
        <!-- 
        -- Buat sebuah input type file
        -- class pull-left berfungsi agar file input berada di sebelah kiri
        -->
        <input type="file" name="file" class="pull-left">
        <?php
      // Jika user telah mengklik tombol Preview
       $nama_file_baru = 'data.xlsx';
        // Cek apakah terdapat file data.xlsx pada folder tmp
        if(is_file('../../tmp/data_barang/'.$nama_file_baru)){ // Jika file tersebut ada
          unlink('../../tmp/data_barang/'.$nama_file_baru); // Hapus file tersebut
        
       // $tipe_file = $_FILES['file']['type']; // Ambil tipe file yang akan diupload
        //$tmp_file = $_FILES['file']['tmp_name'];
        
        // Cek apakah file yang diupload adalah file Excel 2007 (.xlsx)
        //if($tipe_file == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
          // Upload file yang dipilih ke folder tmp
          // dan rename file tersebut menjadi data{ip_address}.xlsx
          // {ip_address} diganti jadi ip address user yang ada di variabel $ip
          // Contoh nama file setelah di rename : data127.0.0.1.xlsx
          move_uploaded_file($tmp_file, '../../tmp/data_barang/'.$nama_file_baru);
          
          // Load librari PHPExcel nya
          require_once '../../PHPExcel/PHPExcel.php';
          
          $excelreader = new PHPExcel_Reader_Excel2007();
          $loadexcel = $excelreader->load('../../tmp/data_barang/'.$nama_file_baru); // Load file yang tadi diupload ke folder tmp
          $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
      
      }
      ?>
      
      </form>

                </div> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_barang/import.php"  name="import" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> coba</a>
                </div>
        
            </div>
        </div>
    </div>
<!-- /.modal -->