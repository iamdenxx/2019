<!-- Add New -->
    <div class="modal fade" id="cetakpdf2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Periode Tanggal Laporan</h4></center>
                </div>
                <div class="modal-body">
				<div class="container-fluid">
				<form method="POST" action="controler/data_report/pdf2.php" target="_blank">

                    <div class="row">
                        <div class="col-lg-2">
                            <label class="control-label" style="position:relative; top:7px;">Kategori:</label>
                        </div>
                        <div class="col-lg-5">
                            <select onchange="cek_database()" required class="form-control" id="kategori_barang" name="kategori_barang">
                                    <option value="" disabled selected>Pilih Kategori</option>;
                                    <?php 
                                    include_once 'includes/koneksi.php';
                                     $query=mysqli_query($konek,"select * from tb_kategori");
                                      while ($data=mysqli_fetch_array($query))
                                     {
                                     echo "<option value='".$data['kategori']."'>".$data['kategori']."</option>";
                                    }
                                    ?>
                                </select>
                        </div>
                    </div>
                    <div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label class="control-label" style="position:relative; top:7px;">Dari Tanggal:</label>
						</div>
						<div class="col-lg-10">
							<input type="date" class="form-control" name="tgl_a" required>
						</div>
					</div>
                    <div style="height:10px;"></div>
                    <div class="row">
                        <div class="col-lg-2">
                            <label class="control-label" style="position:relative; top:7px;">Sampai Tanggal:</label>
                        </div>
                        <div class="col-lg-10">
                            <input type="date" class="form-control" name="tgl_b" required>
                        </div>
                    </div>
                    <div style="height:20px;"></div>
                    <div class="row">
                        <div class="col-lg-2">
                            <label class="control-label" style="position:relative; top:7px;"></label>
                        </div>
                    <div class="col-lg-10">
                    <input  type="submit" name="cetak_data" value="Print" class="btn btn-primary" class="glyphicon glyphicon-print">
                  </div>
              </div>
					
                </div> 
				</div>
                <div class="modal-footer">
                    <!--
                    <a href="data_report/pdf.php" type="submit" target="_blank" class="btn btn-primary" class="glyphicon glyphicon-print"> Print</a>-->
				</form>
          </div>
				
            </div>
        </div>
    </div>
