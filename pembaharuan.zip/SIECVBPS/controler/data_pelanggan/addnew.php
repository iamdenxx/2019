<?php
	include('../../includes/koneksi.php');
	
	$pelanggan=$_POST['pelanggan'];
	$alamat=$_POST['alamat'];
	$status=$_POST['status'];
	

	mysqli_query($konek,"insert into tb_pelanggan (pelanggan,alamat,status) values ('$pelanggan','$alamat','$status')");
	header('location:../../data_pelanggan.php');
?>