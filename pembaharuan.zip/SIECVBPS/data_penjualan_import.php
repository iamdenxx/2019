<?
include_once 'includes/koneksi.php';
include_once 'auth.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SI.Executive Penjualan</title>
	<link href="asset/css/bootstrap.min.css" rel="stylesheet">
	<link href="asset/css/font-awesome.min.css" rel="stylesheet">
	<link href="asset/css/datepicker3.css" rel="stylesheet">
	<link href="asset/css/styles.css" rel="stylesheet">
	<link href="asset/css/scss.css" rel="stylesheet">
	

	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>SIEX</span>PENJUALAN</a>
				<ul class="nav navbar-top-links navbar-right">
					</a>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name">Admin</div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		
<!-- SIDE MENU -->
  <?php require_once("menu.php"); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Data Penjualan</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Data Penjualan</h1>
			</div>
		</div><!--/.row-->
		
		<!-- Main Dasboard -->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Data Penjualan</div>
					<div class="panel-body">
						<div class="col-md-12">
							<div class="row">
      <!-- Buat sebuah tombol Cancel untuk kemabli ke halaman awal / view data -->
      <a href="data_penjualan.php" class="btn btn-danger pull-left">
        <span class="glyphicon glyphicon-remove"></span> Cancel
      </a>
      
      <h3 align="center">Form Import Data</h3>
      <hr>
      
      <!-- Buat sebuah tag form dan arahkan action nya ke file ini lagi -->
      <form method="post" action="" enctype="multipart/form-data">
        <a href="tmp/data_penjualan/Format/Format.xlsx" class="btn btn-default">
          <span class="glyphicon glyphicon-download"></span>
          Download Format
        </a><br><br>
        
        <!-- 
        -- Buat sebuah input type file
        -- class pull-left berfungsi agar file input berada di sebelah kiri
        -->
        <input type="file" name="file" class="pull-left">
        
        <button type="submit" name="preview" class="btn-primary btn-sm">
          <span class="glyphicon glyphicon-eye-open"></span> Preview
        </button>
      </form>
      
      <hr>
      
      <!-- Buat Preview Data -->
      <?php
      // Jika user telah mengklik tombol Preview
      if(isset($_POST['preview'])){
        //$ip = ; // Ambil IP Address dari User
        $nama_file_baru = 'data.xlsx';
        
        // Cek apakah terdapat file data.xlsx pada folder tmp
        if(is_file('tmp/data_penjualan/'.$nama_file_baru)) // Jika file tersebut ada
          unlink('tmp/data_penjualan/'.$nama_file_baru); // Hapus file tersebut
        
        $tipe_file = $_FILES['file']['type']; // Ambil tipe file yang akan diupload
        $tmp_file = $_FILES['file']['tmp_name'];
        
        // Cek apakah file yang diupload adalah file Excel 2007 (.xlsx)
        if($tipe_file == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"){
          // Upload file yang dipilih ke folder tmp
          // dan rename file tersebut menjadi data{ip_address}.xlsx
          // {ip_address} diganti jadi ip address user yang ada di variabel $ip
          // Contoh nama file setelah di rename : data127.0.0.1.xlsx
          move_uploaded_file($tmp_file, 'tmp/data_penjualan/'.$nama_file_baru);
          
          // Load librari PHPExcel nya
          require_once 'PHPExcel/PHPExcel.php';
          
          $excelreader = new PHPExcel_Reader_Excel2007();
          $loadexcel = $excelreader->load('tmp/data_penjualan/'.$nama_file_baru); // Load file yang tadi diupload ke folder tmp
          $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
          
          // Buat sebuah tag form untuk proses import data ke database
          echo "<form method='POST' action='import_penjualan.php'>";
          
          // Buat sebuah div untuk alert validasi kosong
         // echo "<div class='alert alert-danger' id='kosong'>
          //Ada data yang kosong, Ada <span id='jumlah_kosong'></span> data yang belum diisi.
          //</div>";
          echo "<div class='alert alert-danger'>
          Perhatian! Berikut merupakan preview data yg anda import, Tolong cek sebelum diproses.
          </div>";

          echo "<button type='submit' name='import' class='btn btn-primary'><span class='glyphicon glyphicon-upload'></span> Import</button><br/>";
          echo"<div align='center'>";
          echo "<table class='rtable'  id='tabeldata'><br/>
          
           
        <thead>
            <tr>

               
                <th>TGL Transaksi</th>
                <th>Pelanggan</th>
                <th>Type Barang</th>
                <th>Merk</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Qty</th>
                <th>Satuan</th>
                <th>Total</th>
                <th>Jenis Pelanggan</th>
                <th>Jenis Pembayaran</th>
                <th>Transfer</th>
                <th>Cash</th>
                <th>Status</th>
                <th>Sisa</th>
                
                
            </tr>
        </thead>

        <tfoot>
            <tr>

                <th>TGL Transaksi</th>
                <th>Pelanggan</th>
                <th>Type Barang</th>
                <th>Merk</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Qty</th>
                <th>Satuan</th>
                <th>Total</th>
                <th>Jenis Pelanggan</th>
                <th>Jenis Pembayaran</th>
                <th>Transfer</th>
                <th>Cash</th>
                <th>Status</th>
                <th>Sisa</th>
                
                
            </tr>
        </tfoot>

        <tbody>";
          
          $numrow = 1;
          $kosong = 0;
          foreach($sheet as $row){ // Lakukan perulangan dari data yang ada di excel
            // Ambil data pada excel sesuai Kolom
            
            $tgl= $row['C'];
            $pelanggan = $row['K'];
            $type= $row['D'];
            $merk= $row['I'];
            $kategori= $row['J'];
            $harga= $row['G'];
            $qty= $row['E'];
            $satuan= $row['F'];
            $total= $row['H'];
            $jenis_pel= $row['L'];
            $jenis_pem= $row['M'];
            $transfer= $row['N'];
            $cash= $row['O'];
            $status= $row['P'];
            $sisa= $row['Q'];
             // Ambil data Node
           
           
            
            // Cek jika semua data tidak diisi
            if(empty($tgl) && empty($pelanggan) && empty($type) && empty($merk) && empty($kategori) && empty($harga) && empty($qty) && empty($satuan) && empty($total) && empty($jenis_pel) && empty($jenis_pem) && empty($transfer) && empty($cash) && empty($status) && empty($sisa))
              continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)
            
            // Cek $numrow apakah lebih dari 1
            // Artinya karena baris pertama adalah nama-nama kolom
            // Jadi dilewat saja, tidak usah diimport
            if($numrow > 1){
              // Validasi apakah semua data telah diisi
             
              $tgl_td = ( ! empty($tgl))? "" : " style='background: #E07171;'"; // Jika ID Terminal kosong, beri warna merah
              $pelanggan_td = ( ! empty($pelanggan))? "" : " style='background: #E07171;'"; // Jika Pay Unit kosong, beri warna merah
              $type_td = ( ! empty($type))? "" : " style='background: #E07171;'"; // Jika Node kosong, beri warna merah
              $merk_td = ( ! empty($merk))? "" : " style='background: #E07171;'"; // Jika Pay Date kosong, beri warna merah
              $kategori_td = ( ! empty($kategori))? "" : " style='background: #E07171;'"; // Jika Amount kosong, beri warna merah
              $harga_td = ( ! empty($harga))? "" : " style='background: #E07171;'"; // Jika Tarif Package kosong, beri warna merah
              $qty_td = ( ! empty($qty))? "" : " style='background: #E07171;'"; // Jika Code kosong, beri warna merah
              $satuan_td = ( ! empty($satuan))? "" : " style='background: #E07171;'"; // Jika No Tiket kosong, beri warna merah
              $total_td = ( ! empty($total))? "" : " style='background: #E07171;'"; // Jika Masked kosong, beri warna merah
              $jenis_pel_td = ( ! empty($jenis_pel))? "" : " style='background: #E07171;'"; // Jika Card kosong, beri warna merah
              $jenis_pem_td = ( ! empty($jenis_pem))? "" : " style='background: #E07171;'"; // Jika Tarif Package kosong, beri warna merah
              $transfer_td = ( ! empty($transfer))? "" : " style='background: #E07171;'"; // Jika Code kosong, beri warna merah
              $cash_td = ( ! empty($cash))? "" : " style='background: #E07171;'"; // Jika No Tiket kosong, beri warna merah
              $status_td = ( ! empty($status))? "" : " style='background: #E07171;'"; // Jika Masked kosong, beri warna merah
              $sisa_td = ( ! empty($sisa))? "" : " style='background: #E07171;'"; // Jika Card kosong, beri warna merah
             
              
              
              // Jika salah satu data ada yang kosong
             if(empty($tgl) or empty($pelanggan) or empty($type) or empty($merk) or empty($kategori) or empty($harga) or empty($qty) or empty($satuan) or empty($total) or empty($jenis_pel)or empty($jenis_pem) or empty($transfer) or empty($cash) or empty($status) or empty($sisa)){
                $kosong++; // Tambah 1 variabel $kosong
              }
              
              echo "<tr>";
              echo "<td".$tgl_td.">".$tgl."</td>";
              echo "<td".$pelanggan_td.">".$pelanggan."</td>";
              echo "<td".$type_td.">".$type."</td>";
              echo "<td".$merk_td.">".$merk."</td>";
              echo "<td".$kategori_td.">".$kategori."</td>";
              echo "<td".$harga_td.">".$harga."</td>";
              echo "<td".$qty_td.">".$qty."</td>";
              echo "<td".$satuan_td.">".$satuan."</td>";
              echo "<td".$total_td.">".$total."</td>";
              echo "<td".$jenis_pel_td.">".$jenis_pel."</td>";
              echo "<td".$jenis_pem_td.">".$jenis_pem."</td>";
              echo "<td".$transfer_td.">".$transfer."</td>";
              echo "<td".$cash_td.">".$cash."</td>";
              echo "<td".$status_td.">".$status."</td>";
              echo "<td".$sisa_td.">".$sisa."</td>";
              echo "</tr>";
            }
            
            $numrow++; // Tambah 1 setiap kali looping
          }
          
          echo "</table>";
          
          // Cek apakah variabel kosong lebih dari 1
          // Jika lebih dari 1, berarti ada data yang masih kosong
          if($kosong > 1){
          ?>  
            <script>
            $(document).ready(function(){
              // Ubah isi dari tag span dengan id jumlah_kosong dengan isi dari variabel kosong
              $("#jumlah_kosong").html('<?php echo $kosong; ?>');
              
              $("#kosong").show(); // Munculkan alert validasi kosong
            });
            </script>
          <?php
          }else{ // Jika semua data sudah diisi
            echo "<hr>";
            
            // Buat sebuah tombol untuk mengimport data ke database
           // echo "<button type='submit' name='import' class='btn btn-primary'><span class='glyphicon glyphicon-upload'></span> Import</button>";
          }
          
          echo "</form>";
        }else{ // Jika file yang diupload bukan File Excel 2007 (.xlsx)
          // Munculkan pesan validasi
          echo "<div class='alert alert-danger'>
          Hanya File Excel 2007 (.xlsx) yang diperbolehkan
          </div>";
        }
      }
      ?>
  <div class="col-sm-12">
        <p class="back-link">Sistem Informasi Exsecutive Penjualan <span><a>copyright 2019</a></span></p>
      </div>
    </div><!--/.row-->
  </div>  <!--/.main-->
  
  <script src="asset/js/jquery-1.11.1.min.js"></script>
  <script src="asset/js/bootstrap.min.js"></script>
  <script src="asset/js/chart.min.js"></script>
  <script src="asset/js/chart-data.js"></script>
  <script src="asset/js/easypiechart.js"></script>
  <script src="asset/js/easypiechart-data.js"></script>
  <script src="asset/js/bootstrap-datepicker.js"></script>
  <script src="asset/js/custom.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <script src="asset/js/table.js"></script>
  <script>
    window.onload = function () {
  var chart1 = document.getElementById("line-chart").getContext("2d");
  window.myLine = new Chart(chart1).Line(lineChartData, {
  responsive: true,
  scaleLineColor: "rgba(0,0,0,.2)",
  scaleGridLineColor: "rgba(0,0,0,.05)",
  scaleFontColor: "#c5c7cc"
  });
};
  </script>

<!-- Script Table -->   
    <script>
      $(document).ready(function() {
        $('#tabeldata').DataTable();
    });
    </script>
</body>
</html>