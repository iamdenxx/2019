<?
include_once 'includes/koneksi.php';
include_once 'auth.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SI.Executive Penjualan</title>
	<link href="asset/css/bootstrap.min.css" rel="stylesheet">
	<link href="asset/css/font-awesome.min.css" rel="stylesheet">
	<link href="asset/css/datepicker3.css" rel="stylesheet">
	<link href="asset/css/styles.css" rel="stylesheet">
	<link href="asset/css/scss.css" rel="stylesheet">
	

	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>SIEX</span>PENJUALAN</a>
				<ul class="nav navbar-top-links navbar-right">
					</a>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name">Admin</div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		
<!-- SIDE MENU -->

<?php require_once("menu.php"); ?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="index.php">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Data Barang</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Data Barang</h1>
			</div>
		</div><!--/.row-->
		
		<!-- Main Dasboard -->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Data Barang</div>
					<div class="panel-body">
						<div class="col-md-12">
							<div class="row">
		
		 <?php include('controler/data_barang/add_modal.php'); ?>
		<div class="col-md-6 text-left">
			<a href="data_barang_import.php"  class="btn btn-primary"><span class="glyphicon glyphicon-upload"></span> Import Data</a>
		</div>
		<div class="col-md-6 text-right">
			<a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Data</a>
		</div>
	</div>
	<br/>
	<br/>
	<br/>

	<table width="100%" class="rtable" id="tabeldata">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>ID Barang</th>
                <th>Type Barang</th>
                <th>Merk</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th width="20%">Aksi</th>
            </tr>
        </thead>

        <tfoot>
            <tr>
                <th>No</th>
                <th>ID Barang</th>
                <th>Type Barang</th>
                <th>Merk</th>
                <th>Kategori</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </tfoot>

        <tbody>
<?php
include_once 'includes/koneksi.php';
$no=1;
$hasil = mysqli_query($konek,"select * from tb_barang");
	while ($data=mysqli_fetch_array($hasil)) {
?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $data['id_barang'] ?></td>
                <td><?php echo $data['type_barang'] ?></td>
                <td><?php echo $data['merk'] ?></td>
                <td><?php echo $data['kategori'] ?></td>
                <td><?php echo $data['harga'] ?></td>
                <td class="text-center">
				<a href="#edit<?php echo $data['id_barang']; ?>" data-toggle="modal" class="btn btn-primary m-r-1em" ><span class="glyphicon glyphicon-edit"></span> </a>
                <a href="#del<?php echo $data['id_barang']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
              <?php include('controler/data_barang/button.php'); ?>
			    </td>
            </tr>
<?php
}
?>
        </tbody>
        </table>		
        </div>
        </div>
        </div><!-- /.panel-->
		
			<div class="col-sm-12">
				<p class="back-link">Sistem Informasi Exsecutive Penjualan <span><a>copyright 2019</a></span></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="asset/js/jquery-1.11.1.min.js"></script>
	<script src="asset/js/bootstrap.min.js"></script>
	<script src="asset/js/chart.min.js"></script>
	<script src="asset/js/chart-data.js"></script>
	<script src="asset/js/easypiechart.js"></script>
	<script src="asset/js/easypiechart-data.js"></script>
	<script src="asset/js/bootstrap-datepicker.js"></script>
	<script src="asset/js/custom.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <script src="asset/js/table.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>

<!-- Script Table -->		
    <script>
    	$(document).ready(function() {
    		$('#tabeldata').DataTable();
		});
    </script>
</body>
</html>