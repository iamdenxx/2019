<?php
session_start();

if(!isset($_SESSION['username'])){
	
	echo '<script language="javascript">alert("Anda Harus Login !"); document.location="login.php";</script>';
}
?>