<?php
	include('../../includes/koneksi.php');
	
	$name=$_POST['name'];
	$username=$_POST['username'];
	$password = password_hash($_POST["password"], PASSWORD_DEFAULT);
	$level=$_POST['user_level'];
	

	mysqli_query($konek,"insert into tb_user (nama,username,password,user_level) values ('$name','$username','$password','$level')");
	header('location:../../data_user.php');

?>