<?php
	include('../../includes/koneksi.php');

	
	
	$id=$_GET['id'];
	
	$name=$_POST['name'];
	$usename=$_POST['username'];
	$password = password_hash($_POST["password"], PASSWORD_DEFAULT);
	
	
	mysqli_query($conn,"update tb_user set nama='$name', username='$username', password='$password' where id='$id'");
	header('location:../../data_user.php');

?>
