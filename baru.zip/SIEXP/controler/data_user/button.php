<!-- Delete -->
    <div class="modal fade" id="del<?php echo $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Apakah Anda Akan Menghapus Data Berikut ?</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($konek,"select * from tb_user where id='".$data['id']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">

					<h5><center>Nama</center>
						<strong><center><?php echo $drow['nama']; ?></strong></center>
					</h5> 
					<h5><center>Username</center>
					<strong><center><?php echo $drow['username']; ?></strong></center>
				</h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                    <a href="controler/data_user/delete.php?id=<?php echo $data['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Edit -->
    <div class="modal fade" id="edit<?php echo $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel"><b>EDIT DATA USER</b></h4></center>
                </div>
               
                <div class="modal-body">
				<?php
					$edit=mysqli_query($konek,"select * from tb_user where id='".$data['id']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="controler/data_user/edit.php?id=<?php echo $erow['id']; ?>">
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Nama:</label>
						</div>
						<div class="col-lg-6">
							<input type="text" name="name" class="form-control" value="<?php echo $erow['nama']; ?>">
						</div>
					</div>
					
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Username:</label>
						</div>
						<div class="col-lg-6">
							<input type="text" name="username" class="form-control" value="<?php echo $erow['username']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2">
							<label style="position:relative; top:7px;">Password:</label>
						</div>
						<div class="col-lg-6">
							<input type="Password" name="password" class="form-control">
						</div>
					</div>
					 <div><p align="right"><i> * Jika password tidak diubah, diharapkan dibiarkan kosong</i></p></div>
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span></span> Cancel</button>
                   <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</a>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->