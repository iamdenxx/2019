<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$tgl=$_POST['tgl_transaksi'];
	$pelanggan=$_POST['pelanggan'];
	$type=$_POST['type_barang'];
	
	$merk=$_POST['merk_barang'];
	$kategori=$_POST['kategori'];
	$harga=$_POST['harga'];
	$qty=$_POST['qty'];
	$total=$_POST['total'];
	$j_pelanggan=$_POST['jenis_pelanggan'];
	$j_pembayaran=$_POST['jenis_pembayaran'];
	$s_pembayaran=$_POST['status_pembayaran'];
	

	mysqli_query($konek,"update tb_penjualan set tgl_transaksi='$tgl',nama_pelanggan='$pelanggan', type_barang='$type', merk_barang='$merk', kategori_barang='$kategori', harga='$harga', qty='$qty',total='$total',jenis_pelanggan='$j_pelanggan',jenis_pembayaran='$j_pembayaran',status_pembayaran='$s_pembayaran' where id_transaksi='$id'");

	header('location:../../data_penjualan.php');
    
?>