<?php
	include('../../includes/koneksi.php');
	
	$kategori=$_POST['kategori'];
	

	mysqli_query($konek,"insert into tb_kategori (kategori) values ('$kategori')");
	header('location:../../data_kategori.php');
?>