<?php
	include('../../includes/koneksi.php');
	$id=$_GET['id'];
	mysqli_query($konek,"delete from tb_kategori where id_kategori='$id'");
	header('location:../../data_kategori.php');

?>