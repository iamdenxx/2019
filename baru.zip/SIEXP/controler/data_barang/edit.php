<?php
	include('../../includes/koneksi.php');

	$id=$_GET['id'];

	$type_barang=$_POST['type_barang'];
	$merk=$_POST['merk'];
	$kategori=$_POST['kategori'];
	$harga=$_POST['harga'];



	mysqli_query($konek,"update tb_barang set type_barang='$type_barang', merk='$merk', kategori='$kategori',harga='$harga' where id_barang='$id'");

	header('location:../../data_barang.php');

?>