<?php
require('../../includes/fpdf/fpdf.php');



class PDF extends FPDF
{
// Page header
function Header()
{

    $this->Image('../../../images/logo.jpg',10,5,25);
    
    // Judul
    // Geser Ke Kanan
     
    $this->Cell(120);
    $this->SetFont('Arial','B',14);
    $this->Cell(30,7,'LAPORAN PENJUALAN',0,1,'L');
    $this->Cell(100);
    $this->SetFont('Arial','B',16);
    $this->Cell(30,7,'CV. BANUA PARMA SEJAHTERA',0,1,'L');
    $this->Cell(80);
    $this->SetFont('Arial','B',10);
    $this->Cell(30,7,'Jl. Raya Kuta No. 21B, Kuta, Badung-Bali',0,1,'L');
   
    

    // Garis Bawah Double
    $this->SetLineWidth(1);
    $this->Line(10,36,285,36);
    $this->SetLineWidth(0);
    $this->Line(10,37,285,37);
   
   

    // Line break 5mm
    $this->Ln(10);
}

// Page footer
function Footer()
{
   date_default_timezone_set('Singapore');
    $tgl = date('d F Y H:i:s A');
    // Posisi 15 cm dari bawah
    $this->SetY(-15);
    $this->Cell(155);
    $this->SetFont('Arial','I',8);
    $this->Cell(0,10,$tgl);
    $this->SetY(-15);
    

    // Arial italic 8
    $this->SetFont('Arial','I',8);
    

    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C'); 

}
}

//Membuat file PDF
$pdf = new PDF();

//Alias total halaman dengan default {nb} (berhubungan dengan PageNo())
$pdf->AliasNbPages();

$pdf->AddPage();
$pdf->SetFont('Times','',12);

//isi dokumen disini
include('../../includes/koneksi.php');

//if(isset($_POST['print'])){ // Jika user mengklik tombol Import



    // Buat query Insert
   $tgl1=$_POST['tgl_a'];
   $tgl2=$_POST['tgl_b'];

	

	$query="SELECT * from tb_penjualan where (tgl_transaksi) between '$tgl1' and '$tgl2' order by tgl_transaksi ASC";
	
   


    // Eksekusi $query
    $result=mysqli_query($konek,$query);
    $pdf=new PDF();
    $pdf->AddPage();
    $pdf->AliasNbPages();
    $pdf->SetFont('Arial','',12);

$pdf->Cell(30,7,'Berikut adalah rangkuman penjualan :');

$pdf->SetY(50);
$pdf->SetX(10);
$pdf->SetFont('Arial','B',9); 
$pdf->SetFillColor(193,229,252);
$pdf->Cell(10,7,'No',1,0,'C',true); 
$pdf->Cell(20,7,'TGL',1,0,'C',true); 
$pdf->Cell(30,7,'Nama Pelanggan',1,0,'C',true); 
$pdf->Cell(20,7,'Type Barang',1,0,'C',true); 
$pdf->Cell(20,7,'Harga',1,0,'C',true);
$pdf->Cell(20,7,'Jumlah',1,0,'C',true);
$pdf->Cell(20,7,'Total',1,0,'C',true);
$pdf->Cell(30,7,'Merk',1,0,'C',true);
$pdf->Cell(20,7,'Kategori',1,0,'C',true);
$pdf->Cell(30,7,'Jenis Pelanggan',1,0,'C',true);
$pdf->Cell(30,7,'Jenis Pembayaran',1,0,'C',true);
$pdf->Cell(30,7,'Status Pembayaran',1,0,'C',true);

$pdf->SetFont('Arial','',9); 
$pdf->Ln();
    $i=1;
    while($row=mysqli_fetch_array($result))
   
    {
       
        $pdf->SetX(10);
        $pdf->SetFillColor(255,255,255); 
        
        $pdf->Cell(10,7,$i++,1,0,'L',true);
        $pdf->Cell(20,7,$row['tgl_transaksi'],1,0,'L',true); 
        $pdf->Cell(30,7,$row['nama_pelanggan'],1,0,'C',true); 
        $pdf->Cell(20,7,$row['type_barang'],1,0,'C',true);
        $pdf->Cell(20,7,$row['harga'],1,0,'C',true);
        $pdf->Cell(20,7,$row['qty'],1,0,'C',true);
        $pdf->Cell(20,7,$row['total'],1,0,'C',true);
        $pdf->Cell(30,7,$row['merk_barang'],1,0,'C',true);
        $pdf->Cell(20,7,$row['kategori_barang'],1,0,'C',true);
        $pdf->Cell(30,7,$row['jenis_pelanggan'],1,0,'C',true); 
        $pdf->Cell(30,7,$row['jenis_pembayaran'],1,0,'C',true);
        $pdf->Cell(30,7,$row['status_pembayaran'],1,0,'C',true);
       

        $pdf->Ln();

}
       
        

//Mencetak kalimat dengan perulangan
//for($i=1;$i<=45;$i++)
   // $pdf->Cell(0,10,'Baris '.$i,0,1);

//Menutup dokumen dan dikirim ke browser

$pdf->Output();


?>